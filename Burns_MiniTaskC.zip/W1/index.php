<?php

$animals = [
    'Lion',
    'Tiger',
    'Bear',
    'Wolf',
    'Peacock',
    'Owl',
    'Platypus'
];

require 'index.view.php';